# License

Forsetti Framework is proprietary software owned by James Daley.

## Evaluation

You may access the repository and wiki to evaluate Forsetti for internal assessment. Evaluation access does not grant production, redistribution, sublicensing, or commercial deployment rights.

## Commercial Use

Commercial use is not permitted.

Commercial licensing is not yet available. No commercial use may begin unless and until separate written commercial license terms are made available and written permission is granted.

## Personal or Non-Commercial Use

Personal use, non-commercial academic use, educational research, evaluation, and testing are permitted only within the terms of `LICENSE.md`.

## Practical Guidance

| Activity | Status |
| --- | --- |
| Reading the repository and wiki for evaluation | Permitted for assessment. |
| Building proof-of-concept integrations for evaluation | Permitted only within evaluation scope. |
| Shipping a commercial app using Forsetti | Not permitted; commercial licensing is not yet available. |
| Copying Forsetti source into another product | Not permitted without written authorization. |
| Redistributing Forsetti as part of another framework or SDK | Not permitted without written authorization. |

For full legal terms, see `LICENSE.md` in the main repository.
