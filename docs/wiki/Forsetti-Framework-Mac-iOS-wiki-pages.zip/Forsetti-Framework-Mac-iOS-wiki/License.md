# License

Forsetti Framework is open source under the [Apache License, Version 2.0](https://github.com/flynn33/Forsetti-Framework-Mac-iOS/blob/main/LICENSE).
Copyright 2026 James Daley.

Use, modification, and redistribution are governed by that license. Preserve applicable license and attribution notices when distributing framework code, dependencies, or permitted scaffold material. See the main repository's `LICENSE` for the full terms.

## Supported Integration

The [Consumption Policy](https://github.com/flynn33/Forsetti-Framework-Mac-iOS/blob/main/CONSUMPTION_POLICY.md) defines the supported engineering integration surface: the public Swift package products and explicitly designated Xcode scaffold outputs.

It directs consumer applications to use a remote package dependency and app-owned projects/modules, and prohibits using a copied or vendored framework repository as the application foundation. This is an engineering and supported-integration policy, not an additional license restriction. It does not amend or replace `LICENSE`.

Outside contributions to the main repository are not accepted. See [Contributing](https://github.com/flynn33/Forsetti-Framework-Mac-iOS/blob/main/CONTRIBUTING.md) for the repository's contribution policy.
