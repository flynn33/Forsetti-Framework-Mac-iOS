# Xcode Templates

Forsetti ships Xcode templates for a production starter app, UI modules, service modules, and standalone manifests.

The approved scaffolds are the four `.xctemplate` directories under `XcodeTemplates/Project Templates/Forsetti/`. Install them into Xcode or adapt only their designated scaffold source/JSON files into an independent app-owned project, following the [Consumption Policy](https://github.com/flynn33/Forsetti-Framework-Mac-iOS/blob/main/CONSUMPTION_POLICY.md).

`ForsettiHostTemplate` is a compiled package library, not a folder of app scaffolds to copy. Do not use the repository root or its `Sources/` tree as the application's foundation.

## Template Set

| Template | Creates | Use When |
| --- | --- | --- |
| Forsetti App | App target starter with app module, manifest, deployment mode, bootstrap, and module registry. | Starting a new Forsetti-based app. |
| Forsetti UI Module | UI module class, SwiftUI view, and manifest. | Adding a visual feature module. |
| Forsetti Service Module | Service module class and manifest. | Adding background behavior. |
| Forsetti Manifest | Standalone manifest file. | Adding or repairing manifest resources. |

## Installation Workflow

```mermaid
flowchart TD
    A["Extract curated Forsetti SDK outside consumer tree"] --> B["Run development-time install script"]
    B --> C["Create ~/Library/Developer/Xcode/Templates/Project Templates/Forsetti"]
    C --> D["Copy Forsetti templates"]
    D --> E["Open Xcode"]
    E --> F["Choose Forsetti template"]
```

```bash
FORSETTI_SDK="/path/to/Forsetti-SDK-0.2.0"
"$FORSETTI_SDK/Scripts/install-forsetti-xcode-template.sh"
# Optional custom category directory:
"$FORSETTI_SDK/Scripts/install-forsetti-xcode-template.sh" \
  --destination "/path/with spaces/Forsetti"
```

Use the extracted [Forsetti SDK](Forsetti-SDK). The installer locates the approved payloads relative to its own script, regardless of current directory. A separate framework checkout remains an optional development/evaluation path; it is not required for SDK onboarding. The installer, `.xctemplate` directories, and `TemplateInfo.plist` are development-time material and must not be added to consumer targets or the shipping app bundle. Neither the kit nor a checkout becomes a vendored dependency, submodule, subtree, or copied app foundation.

To remove installed templates:

```bash
"$FORSETTI_SDK/Scripts/uninstall-forsetti-xcode-template.sh"
# For the custom category above:
"$FORSETTI_SDK/Scripts/uninstall-forsetti-xcode-template.sh" \
  --destination "/path/with spaces/Forsetti"
```

Both utilities operate on the four allowlisted Forsetti templates; unrelated installed templates are preserved. Development tools use Bash/system Python 3.9 or newer and do not require Homebrew or Node.

## Noninteractive Scaffold Generation

```bash
"$FORSETTI_SDK/Scripts/generate-forsetti-scaffold.sh" \
  --template app --name MyApplication \
  --module-id com.example.myapplication \
  --output "/path/to/My Application/App"
```

The generator reads the same approved `TemplateInfo.plist` definitions and Swift/JSON payloads used by Xcode. It validates Swift names/reverse-DNS module IDs, resolves placeholders and sample identities, reports exact inputs/outputs, and rejects unintended overwrites. Supply an app-owned identity. Other selections are `--template ui`, `--template service`, and `--template manifest`.

Before generation, name the selected products and exact input/output destinations. Add the reported Swift files to the owning target's source phase and manifests to its resource phase. Include the generated `Resources/ForsettiManifests` as a folder resource, preserving `ForsettiManifests` in the built owning bundle; ordinary source folders/Xcode groups do not establish bundle layout. The supplied app bootstrap uses `Bundle.main`; a module package must supply its actual resource bundle when it owns manifests.

Use the exact runtime commit from the extracted kit's `sdk-manifest.json` and retain `Package.resolved`. After building/running, inspect the actual app/resource bundle with `verify-forsetti-integration.sh` and perform runtime discovery/activation checks. The verifier's static findings and coverage limits do not replace those checks.

## Production Starter Architecture

```mermaid
flowchart LR
    ContentView["ContentView"] --> Mode{"DeploymentMode.current"}
    Mode -- development --> HostRoot["ForsettiHostRootView<br/>developer controls"]
    Mode -- production --> Gate["Production root<br/>boot and activate"]
    Gate --> AppView["AppModuleView<br/>product UI after activation"]
    ContentView --> Bootstrap["ForsettiBootstrap"]
    Bootstrap --> Registry["ModuleRegistry.registerAll"]
    Bootstrap --> Controller["ForsettiHostController"]
    Controller --> Runtime["ForsettiRuntime"]
```

The generated app starts in development mode so the module controls are visible immediately. Switch to production mode before shipping end-user builds. Production mode does not render the app module view until runtime boot and explicit app module activation have succeeded.

## Generated App Files

| File | Purpose |
| --- | --- |
| `AppModule.swift` | App-owned `ForsettiAppModule` implementation. |
| `AppModuleManifest.json` | Manifest for the starter app module. |
| `AppModuleView.swift` | Starter SwiftUI product surface. |
| `DeploymentMode.swift` | Development vs production switch. |
| `ForsettiBootstrap.swift` | Runtime/controller wiring. |
| `ModuleRegistry.swift` | Registers app-owned module factories. |
| `ContentView.swift` | Chooses developer shell or production app UI. |

The starter app module manifest includes `view_injection` because the generated app module contributes its primary view through `UIContributions`.

Resolve template placeholders and replace sample identities with app-owned identities. Keep Swift descriptors, module registrations, and JSON manifests aligned, and preserve the runtime boot and activation checks. Load manifests from the bundle that owns the app's resources, not `ExampleModuleResources.bundle`.

Add the remote Forsetti Swift package dependency, record its resolved version/revision through the application's dependency-resolution workflow, and select the products each target needs. The app scaffold uses `ForsettiCore`, `ForsettiPlatform`, and `ForsettiHostTemplate`; an app-owned module that only uses core contracts need not directly depend on the platform or host products. Do not use a copied framework tree with `.package(path:)`, invent `import ForsettiFramework`, or expose `ForsettiModulesExample` as a consumer product.

## Template Manifest Contract

New templates should emit schema `1.1` manifests with manifest template `1.1`. The manifest should declare capabilities and runtime requirements together so activation failures are diagnosable from the manifest alone.

```json
{
  "schemaVersion": "1.1",
  "manifestTemplateVersion": "1.1",
  "moduleID": "com.example.app.module",
  "displayName": "Example App Module",
  "moduleVersion": {
    "major": 1,
    "minor": 0,
    "patch": 0
  },
  "moduleType": "app",
  "supportedPlatforms": ["iOS", "macOS"],
  "minForsettiVersion": {
    "major": 0,
    "minor": 1,
    "patch": 1
  },
  "maxForsettiVersion": null,
  "capabilitiesRequested": ["view_injection", "toolbar_items"],
  "iapProductID": null,
  "entryPoint": "ExampleAppModule",
  "defaultModuleRole": "ui",
  "runtimeRequirements": {
    "io": [],
    "ui": {
      "viewIDs": ["example.primary"],
      "slotIDs": ["main"],
      "toolbarItemIDs": ["example.refresh"],
      "routeIDs": [],
      "pointerIDs": []
    },
    "dataIsolation": {
      "mode": "private_to_module",
      "ownedStoreIDs": [],
      "requiredDefaultRoles": []
    }
  }
}
```

```mermaid
flowchart TD
    Template["Xcode template"] --> Swift["Swift module class"]
    Template --> Manifest["Schema 1.1 manifest"]
    Manifest --> Capabilities["capabilitiesRequested"]
    Manifest --> Runtime["runtimeRequirements"]
    Swift --> Registry["entryPoint registration"]
    Runtime --> Activation["Runtime validation before start(context)"]
    Registry --> Activation
```

## Template Authoring Flow

```mermaid
flowchart TD
    A["Create module with Xcode template"] --> B["Add Forsetti package products"]
    B --> C["Confirm manifest is in Resources/ForsettiManifests"]
    C --> D["Register entry point"]
    D --> E["Register injected views if UI/app module"]
    E --> F["Boot in development mode"]
    F --> G["Run tests and guardrails"]
    G --> H["Switch production mode when ready"]
```

## Common Template Fixes

| Symptom | Fix |
| --- | --- |
| Template appears but app does not compile | Add `ForsettiCore`, `ForsettiPlatform`, and `ForsettiHostTemplate` products to the target. |
| Manifest is not discovered | Confirm target resource membership, built `ForsettiManifests` layout, and the actual owning bundle passed to the loader. |
| Module does not activate | Confirm `entryPoint` matches the registry key. |
| Activation fails with `unsatisfiedRuntimeRequirement` | Confirm capabilities, runtime requirements, default roles, and host providers are aligned. |
| Module activates in development but not production | Confirm production boot uses the configured app module ID and that activation succeeds before rendering. |
| Injected view is blank | Register the `viewID` in `ForsettiViewInjectionRegistry`. |
| Production UI still shows controls | Set deployment mode to production and use the generated production root path. |
