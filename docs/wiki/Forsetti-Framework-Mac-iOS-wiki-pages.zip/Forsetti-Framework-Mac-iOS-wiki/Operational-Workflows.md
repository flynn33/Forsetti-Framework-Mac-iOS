# Operational Workflows

Forsetti keeps repository source and GitHub Wiki content separate. The wiki is maintained directly in the wiki repository so rich diagrams, architecture maps, and hand-curated operational pages remain reviewable as their own surface.

## Manual Wiki Maintenance

```mermaid
flowchart TD
    A["Clone or pull Forsetti-Framework-Mac-iOS.wiki"] --> B["Edit Markdown pages directly"]
    B --> C["Validate links and Mermaid blocks"]
    C --> D["Commit wiki changes"]
    D --> E["Push wiki master"]
    E --> F["Review rendered GitHub Wiki"]
```

Wiki repository:

```bash
git clone https://github.com/flynn33/Forsetti-Framework-Mac-iOS.wiki.git
```

## Version and Release Workflow

Hosted PR version, title lint, and guardrail workflows were removed on August 16, 2026. Version updates and verification now require intentional local commands; `Scripts/update-pr-version.py` remains available when a version update is intended.

```mermaid
flowchart TD
    Change["Owner-reviewed change"] --> Version["Align version files locally when updating version"]
    Version --> Checks["Run local tests and guardrails"]
    Checks --> Publish["Owner-controlled publication to main"]
    Publish --> Release["Separate release process"]
    Release --> ReleaseOutputs["Tag, changelog, and GitHub release when applicable"]
    Release --> Docs["Review README and wiki for user-facing changes"]
```

The retained version script does not commit, push, publish releases, or update the wiki. Wiki updates are intentional documentation changes that are committed directly to the wiki repository.
For detailed version bump rules, see [Versioning and Releases](Versioning-and-Releases).

When wiki pages change, regenerate the tracked archive in the main repository:

```bash
git -C /path/to/Forsetti-Framework-Mac-iOS.wiki archive \
  --format=zip \
  --output=/path/to/Forsetti-Framework-Mac-iOS/docs/wiki/Forsetti-Framework-Mac-iOS-wiki-pages.zip \
  --prefix=Forsetti-Framework-Mac-iOS-wiki/ \
  HEAD
```

## Version Update Checklist

| File | Expected Update |
| --- | --- |
| `Sources/ForsettiCore/ForsettiVersion.swift` | Runtime version constant. |
| `version.txt` | Plain version value. |
| `.release-please-manifest.json` | Retained release configuration state; not changed by the local version script. |
| `README.md` | Visible version and release links. |
| `CHANGELOG.md` | User-facing changes when a release PR is prepared. |
| Wiki pages | Manual update only when architecture, API, workflows, or integration guidance changes. |
| `docs/wiki/Forsetti-Framework-Mac-iOS-wiki-pages.zip` | Regenerated after wiki page changes so the repository archive mirrors the published wiki. |

## Local SDK Packaging and Verification

Framework maintainers assemble SDK 0.2.0 from a reviewed allowlist of authoritative repository inputs. Packaging lives in the framework repository; generated ZIP/checksum files go to ignored output directories. This workflow does not add hosted automation, commit/push changes, or publish a tag/release automatically.

Read the [SDK release procedure](https://github.com/flynn33/Forsetti-Framework-Mac-iOS/blob/main/docs/sdk/releasing.md), align runtime/version surfaces, and identify a clean source revision plus a remotely verified immutable runtime commit/tag. Supply a verification report describing the environments and checks actually exercised. From the clean framework repository:

```bash
FORSETTI_RUNTIME_COMMIT="<verified full runtime commit>"
python3 Scripts/package-forsetti-sdk.py \
  --source-ref HEAD --runtime-ref "$FORSETTI_RUNTIME_COMMIT" \
  --verification-report "/path/to/actual-sdk-verification.json" \
  --output output/sdk/0.2.0
python3 Scripts/verify-forsetti-sdk.py \
  --archive output/sdk/0.2.0/Forsetti-SDK-0.2.0.zip \
  --checksums output/sdk/0.2.0/SHA256SUMS \
  --source-repo .
```

Replace the example commit/report values with recorded evidence. The separate verifier checks inventory/hashes, executable modes, canonical policy equality against the recorded Git source, template/product boundaries, and SDK-local links/upstream reference mappings. Extract the archive and test its installer/uninstaller/generator independently, including paths with spaces and overwrite protections. Build/run independent clean consumers using the extracted kit and declared remote dependency on macOS/iOS Simulator; inspect device compilation separately from installation, and exercise a governed rejection path.

`sdk-manifest.json` records source/runtime commits, canonical policy provenance, inventory hashes, requirements, actual environments/checks, and release status. Missing qualification keeps the output an `unverified-candidate`; explicit dirty development inputs produce a `development-candidate`. Archive integrity alone does not authorize a release-ready claim. Hash the final ZIP externally in `SHA256SUMS`; the manifest excludes itself from its own file-hash inventory.

Publish the curated ZIP and external checksum as separate release assets only when authorized and qualified. Keep GitHub's automatic source archives identified as source archives. Review the final source/wiki/version state and regenerate the wiki archive through the manual workflow above.

## Consumer Integration Workflow

Read the [Consumption Policy](https://github.com/flynn33/Forsetti-Framework-Mac-iOS/blob/main/CONSUMPTION_POLICY.md) before edits. Identify whether the work is framework maintenance or consumer integration; reading framework source while building an app does not make that app a framework-maintenance project.

Use the extracted [Forsetti SDK](Forsetti-SDK) and its recorded exact runtime revision for the consumer path. The separately named curated ZIP is not GitHub's automatic source archive. Consumer instructions/tools work outside a framework checkout; an app-owned local module package may depend on the remote public runtime products without vendoring the framework.

1. Name the selected public products (`ForsettiCore`, `ForsettiPlatform`, and/or `ForsettiHostTemplate`) and exact approved scaffold files to generate or adapt, with their consumer destinations.
2. Create or retain an independent app-owned Xcode project and module targets. Add the remote SwiftPM/Xcode dependency and select only the products each target needs. Record the resolved version/revision through the app's dependency-resolution workflow.
3. Generate or adapt app-owned files from the kit's `XcodeTemplates/Project Templates/Forsetti/`, through Xcode or `generate-forsetti-scaffold.sh`. Keep app identities, feature code, registrations, and manifests in the consumer project. `ForsettiHostTemplate` remains a compiled dependency; do not copy its implementation sources.
4. Load manifests from their owning app/module bundle, not `ExampleModuleResources.bundle`. Preserve compatibility, entitlement, and runtime activation checks before rendering.
5. Run the consumer integration verifier with the expected runtime commit and built owning app/resource bundle. Review target dependencies, source/resource membership, tracked files, resource-content equality, and the report's coverage limitations. Confirm that no framework source tree, example target/resources, template metadata, wiki archive, or framework-maintenance infrastructure was copied into the app. Perform runtime discovery/activation tests separately.
6. Report selected products, generated/adapted files, and verification results. State unavailable checks explicitly; the policy document does not scan a consumer filesystem or prove compliance.

SwiftPM/Xcode may fetch and cache the dependency. Do not edit or commit that cache or use `.package(path:)` to a vendored Forsetti repository. A separate checkout outside the consumer source tree may be used for documentation, evaluation, template installation, or explicitly requested upstream framework maintenance. It must not become the consumer's project foundation, target, submodule, or subtree.

```mermaid
flowchart TD
    A["Select products and exact scaffolds"] --> B["Add remote dependency to app-owned project"]
    B --> C["Generate app-owned scaffold files"]
    C --> D["Register module factories"]
    D --> E["Bundle manifests"]
    E --> F["Configure services and entitlements"]
    F --> G["Boot runtime"]
    G --> H["Activate modules"]
    H --> I["Audit consumer targets, resources, and tracked files"]
    I --> J["Run consumer checks and report results"]
    J --> K["Switch production presentation"]
```

## Runtime Change Workflow

```mermaid
flowchart TD
    Change["Runtime or API change"] --> Contract["Review public contracts"]
    Contract --> Tests["Add or update tests"]
    Tests --> Docs["Update README/wiki/API reference"]
    Docs --> Version["Confirm version alignment and intended update"]
    Version --> Guardrails["Run swift test and guardrails"]
    Guardrails --> Changelog["Handle changelog during release work"]
```

## Documentation Ownership

| Surface | Ownership |
| --- | --- |
| README | High-level repository entry point. |
| CHANGELOG | Release and change history. |
| GitHub Wiki | Comprehensive architecture and workflow documentation. |
| `SDK/` consumer documentation | Authoritative developer-kit guidance, rendered with recorded release/runtime references during packaging. |
| `docs/sdk/releasing.md` | Maintainer-only local qualification and publication procedure. |
| Source comments | Local API clarification only when code is not self-explanatory. |
| Tests | Executable behavior documentation. |
