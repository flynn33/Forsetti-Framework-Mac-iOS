# Operational Workflows

Forsetti keeps repository source and GitHub Wiki content separate. The wiki is maintained directly in the wiki repository so rich diagrams, architecture maps, and hand-curated operational pages remain reviewable as their own surface.

## Manual Wiki Maintenance

```mermaid
flowchart TD
    A["Clone or pull Forsetti-Framework-Mac-iOS.wiki"] --> B["Edit Markdown pages directly"]
    B --> C["Validate links and Mermaid blocks"]
    C --> D["Commit wiki changes"]
    D --> E["Push wiki master"]
    E --> F["Review rendered GitHub Wiki"]
```

Wiki repository:

```bash
git clone https://github.com/flynn33/Forsetti-Framework-Mac-iOS.wiki.git
```

## Version and Release Workflow

Hosted PR version, title lint, and guardrail workflows were removed on August 16, 2026. Version updates and verification now require intentional local commands; `Scripts/update-pr-version.py` remains available when a version update is intended.

```mermaid
flowchart TD
    Change["Owner-reviewed change"] --> Version["Align version files locally when updating version"]
    Version --> Checks["Run local tests and guardrails"]
    Checks --> Publish["Owner-controlled publication to main"]
    Publish --> Release["Separate release process"]
    Release --> ReleaseOutputs["Tag, changelog, and GitHub release when applicable"]
    Release --> Docs["Review README and wiki for user-facing changes"]
```

The retained version script does not commit, push, publish releases, or update the wiki. Wiki updates are intentional documentation changes that are committed directly to the wiki repository.
For detailed version bump rules, see [Versioning and Releases](Versioning-and-Releases).

When wiki pages change, regenerate the tracked archive in the main repository:

```bash
git -C /path/to/Forsetti-Framework-Mac-iOS.wiki archive \
  --format=zip \
  --output=/path/to/Forsetti-Framework-Mac-iOS/docs/wiki/Forsetti-Framework-Mac-iOS-wiki-pages.zip \
  --prefix=Forsetti-Framework-Mac-iOS-wiki/ \
  HEAD
```

## Version Update Checklist

| File | Expected Update |
| --- | --- |
| `Sources/ForsettiCore/ForsettiVersion.swift` | Runtime version constant. |
| `version.txt` | Plain version value. |
| `.release-please-manifest.json` | Retained release configuration state; not changed by the local version script. |
| `README.md` | Visible version and release links. |
| `CHANGELOG.md` | User-facing changes when a release PR is prepared. |
| Wiki pages | Manual update only when architecture, API, workflows, or integration guidance changes. |
| `docs/wiki/Forsetti-Framework-Mac-iOS-wiki-pages.zip` | Regenerated after wiki page changes so the repository archive mirrors the published wiki. |

## Consumer Integration Workflow

Read the [Consumption Policy](https://github.com/flynn33/Forsetti-Framework-Mac-iOS/blob/main/CONSUMPTION_POLICY.md) before edits. Identify whether the work is framework maintenance or consumer integration; reading framework source while building an app does not make that app a framework-maintenance project.

1. Name the selected public products (`ForsettiCore`, `ForsettiPlatform`, and/or `ForsettiHostTemplate`) and exact approved scaffold files to generate or adapt, with their consumer destinations.
2. Create or retain an independent app-owned Xcode project and module targets. Add the remote SwiftPM/Xcode dependency and select only the products each target needs. Record the resolved version/revision through the app's dependency-resolution workflow.
3. Generate or adapt app-owned files from `XcodeTemplates/Project Templates/Forsetti/`. Keep app identities, feature code, registrations, and manifests in the consumer project. `ForsettiHostTemplate` remains a compiled dependency; do not copy its implementation sources.
4. Load manifests from their owning app/module bundle, not `ExampleModuleResources.bundle`. Preserve compatibility, entitlement, and runtime activation checks before rendering.
5. Inspect target dependencies, source/resource membership, and tracked files. Confirm that no framework source tree, example target/resources, template metadata, wiki archive, or framework-maintenance infrastructure was copied into the app.
6. Report selected products, generated/adapted files, and verification results. State unavailable checks explicitly; the policy document does not scan a consumer filesystem or prove compliance.

SwiftPM/Xcode may fetch and cache the dependency. Do not edit or commit that cache or use `.package(path:)` to a vendored Forsetti repository. A separate checkout outside the consumer source tree may be used for documentation, evaluation, template installation, or explicitly requested upstream framework maintenance. It must not become the consumer's project foundation, target, submodule, or subtree.

```mermaid
flowchart TD
    A["Select products and exact scaffolds"] --> B["Add remote dependency to app-owned project"]
    B --> C["Generate app-owned scaffold files"]
    C --> D["Register module factories"]
    D --> E["Bundle manifests"]
    E --> F["Configure services and entitlements"]
    F --> G["Boot runtime"]
    G --> H["Activate modules"]
    H --> I["Audit consumer targets, resources, and tracked files"]
    I --> J["Run consumer checks and report results"]
    J --> K["Switch production presentation"]
```

## Runtime Change Workflow

```mermaid
flowchart TD
    Change["Runtime or API change"] --> Contract["Review public contracts"]
    Contract --> Tests["Add or update tests"]
    Tests --> Docs["Update README/wiki/API reference"]
    Docs --> Version["Confirm version alignment and intended update"]
    Version --> Guardrails["Run swift test and guardrails"]
    Guardrails --> Changelog["Handle changelog during release work"]
```

## Documentation Ownership

| Surface | Ownership |
| --- | --- |
| README | High-level repository entry point. |
| CHANGELOG | Release and change history. |
| GitHub Wiki | Comprehensive architecture and workflow documentation. |
| Source comments | Local API clarification only when code is not self-explanatory. |
| Tests | Executable behavior documentation. |
