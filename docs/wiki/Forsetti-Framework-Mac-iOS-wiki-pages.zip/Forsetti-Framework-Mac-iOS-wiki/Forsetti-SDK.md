# Forsetti SDK

Forsetti SDK 0.2.0 consists of a curated developer kit plus the existing source-based, pinned remote SwiftPM/Xcode runtime dependency. SwiftPM/Xcode fetches framework source and compiles the selected libraries. The kit contains no runtime `Sources/` tree, runtime `Package.swift`, or prebuilt XCFrameworks; access to the declared remote dependency is required.

**You are integrating Forsetti into an independent application, not developing the Forsetti framework. Read CONSUMPTION_POLICY.md first. Import only the approved public products. Generate or adapt only the designated scaffold outputs. Do not copy, vendor, reconstruct, patch, or use the framework repository as the application's starting tree, even unmodified. The application owns its modules; Forsetti owns its runtime implementation.**

## Downloads and release identity

Use the [0.2.0 release](https://github.com/flynn33/Forsetti-Framework-Mac-iOS/releases/tag/v0.2.0), its separately named [Forsetti-SDK-0.2.0.zip](https://github.com/flynn33/Forsetti-Framework-Mac-iOS/releases/download/v0.2.0/Forsetti-SDK-0.2.0.zip), and external [SHA256SUMS](https://github.com/flynn33/Forsetti-Framework-Mac-iOS/releases/download/v0.2.0/SHA256SUMS). GitHub's automatically generated source-code ZIP/tarball is the framework development repository, not the SDK.

Check the downloaded ZIP before extraction:

```bash
shasum -a 256 -c SHA256SUMS
unzip Forsetti-SDK-0.2.0.zip
```

Keep the extracted kit outside the application's tracked tree. Read its `sdk-manifest.json`: `source.commit` identifies the kit's source revision, `runtime.ref` and `runtime.commit` identify its immutable runtime dependency, and `sdk.releaseStatus` distinguishes an assembled release from a development/unverified candidate. Use the actual `verification.testedEnvironments` and named verification checks for qualification evidence. Minimum platform declarations and a checksum do not establish successful runtime execution or device installation.

## Public runtime products

| Product | Direct dependencies | Consumer role |
| --- | --- | --- |
| `ForsettiCore` | None | Module contracts, manifests, registration, lifecycle, compatibility, capabilities, events, and service contracts. |
| `ForsettiPlatform` | `ForsettiCore` | Native service adapters and entitlement-provider implementations. |
| `ForsettiHostTemplate` | `ForsettiCore`, `ForsettiPlatform` | Reusable host bootstrap/controller, routing, and SwiftUI composition. |

The app scaffold selects all three products. A module using only core contracts selects `ForsettiCore` directly. `ForsettiFramework` is the package name, not an umbrella import; `ForsettiHostTemplate` is a library, not copyable scaffold source. Internal example targets/resources are not consumer products.

## One onboarding path

1. Read the kit's complete `CONSUMPTION_POLICY.md` and `AGENTS.md`. Before edits, name the selected products, exact template inputs, and app-owned output destinations.
2. Create an independent app-owned Xcode project. Add `https://github.com/flynn33/Forsetti-Framework-Mac-iOS` with the exact revision in the kit's `runtime.commit`; retain `Package.resolved` and select the products used by each target. Do not pin mutable `main` or substitute a vendored Forsetti `.package(path:)` dependency. App-owned local module packages remain valid.
3. Generate the app-owned scaffold below, add its Swift files to Compile Sources, and retain exactly one app entry point.
4. Add `Resources/ForsettiManifests` as a folder resource to the target that owns the manifests. Preserve `ForsettiManifests/*.json` in the built bundle; an Xcode group/source directory alone does not prove resource membership.
5. Keep the generated registry, Swift descriptors, and JSON module IDs/entry points aligned. Build/run on the intended Apple platforms, verify discovery and successful activation, and verify the app-owned UI.
6. Run the integration verifier with the actual built app/resource bundle and expected runtime commit, then review its limitations and run app-specific tests.

```bash
FORSETTI_SDK="/path/to/Forsetti-SDK-0.2.0"
FORSETTI_APP="/path/to/My Application"
FORSETTI_RUNTIME_COMMIT="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["runtime"]["commit"])' "$FORSETTI_SDK/sdk-manifest.json")"
"$FORSETTI_SDK/Scripts/generate-forsetti-scaffold.sh" \
  --template app --name MyApplication \
  --module-id com.example.myapplication \
  --output "$FORSETTI_APP/App"
"$FORSETTI_SDK/Scripts/verify-forsetti-integration.sh" \
  --project "$FORSETTI_APP" --bundle "/path/to/MyApplication.app" \
  --runtime-commit "$FORSETTI_RUNTIME_COMMIT" \
  --json "/path/to/integration-report.json"
```

Replace the example module identity with an identity owned by your application. The generator reuses the approved Xcode payloads, validates identifiers, resolves placeholders, reports inputs/outputs as JSON, and rejects overwriting generated files. Use `--template ui`, `--template service`, or `--template manifest` for the other approved scaffolds.

The supplied app bootstrap uses the app-owned manifests in `Bundle.main` and subdirectory `ForsettiManifests`. If an app-owned module package owns resources, pass its resource bundle to the supported bootstrap/runtime API instead. Never substitute an internal example bundle. SwiftPM processing can flatten directories; inspect the actual resource bundle and exercise discovery.

The app scaffold starts in development mode. Switching its generated deployment mode to `.production` uses the boot/activation gate before rendering app-owned UI. Preserve lifecycle, manifest compatibility, entitlement, capability, required service/default-role, and UI contribution checks; do not hide activation errors or patch dependency caches. A single-module application owns its UI in its app module; a multi-module single application has exactly one dedicated UI module plus service modules as needed. App-owned UI/rendering modules may use SwiftUI, Metal, and other appropriate Apple-native frameworks.

## Kit contents and ownership

The kit includes SDK README/consumer guidance, complete canonical `CONSUMPTION_POLICY.md` and `MODULE_BOUNDARY_RULES.md`, `LICENSE` and applicable `NOTICE`, `sdk-manifest.json`, release notes, and five consumer documentation pages. Canonical policy copies are unchanged; their hashes and source paths are recorded in metadata. Repository-only references in those policies are mapped to immutable upstream URLs by `Documentation/Source-References.md`.

The four complete approved templates remain under `XcodeTemplates/Project Templates/Forsetti/`: App, UI Module, Service Module, and Manifest. The four portable development tools are the installer, uninstaller, scaffold generator, and integration verifier. Install from the extracted kit using [Xcode Templates](Xcode-Templates); a development checkout is optional for explicitly requested upstream maintenance or evaluation.

Only generated/adapted app-owned Swift and manifest JSON enter application targets. Template metadata/directories, kit documentation, tools, wiki archives, framework tests, repository maintenance configuration, and runtime implementation copies do not enter app sources/resources or shipping bundles. The consumption policy defines a supported engineering boundary and does not amend the [Apache license](License). Preserve required license and notice material.

## Verification coverage

The integration verifier checks Git-tracked working files (or available project files without Git), actual SwiftPM declarations, explicit Xcode source/resource phases, selected products, exact/resolved runtime pins, mirror overrides, and supplied built-bundle resources. It identifies known runtime implementation copies through declarations, implementation signatures, and normalized source fingerprints; it also checks internal examples, tracked caches, template/maintenance assets, escaping paths, manifest membership, and stale built manifests. Legitimate public imports, required notices, app-owned local module dependencies, and untracked managed caches are permitted.

The JSON report contains examined targets/dependencies/resources, violations, warnings, and coverage limitations. Static inspection does not prove the absence of arbitrarily reconstructed code, certify remote references or untouched cache contents, resolve all dynamic build configuration, or execute activation. Inspect custom build scripts/generated resources and the bundle actually passed to `ManifestLoader`. Treat skipped bundle checks, unresolved membership, and runtime checks as concrete work remaining; a successful static report alone is not runtime qualification.

For detailed commands, follow the extracted kit's `Documentation/Getting-Started.md`, `Public-API.md`, `Module-Authoring.md`, and `Compatibility.md`. Framework-maintainer packaging/publication work is described separately in [Operational Workflows](Operational-Workflows) and the [SDK release procedure](https://github.com/flynn33/Forsetti-Framework-Mac-iOS/blob/main/docs/sdk/releasing.md).

## 0.2.0 Qualification and Published Asset

The signed `v0.2.0` tag resolves to qualified source/runtime commit `a986fbaa1a42919abdfc09c37b1c838706698268`. Release readback confirms `flynn33` as author, the exact tag/target, and the separately named SDK ZIP, checksum, and verification report. Later documentation updates preserve that release and version.

Qualification passed 86 SDK tooling/fixture tests, 81 XCTest cases, and strict lint with zero violations. Three independent consumers produced nine successful macOS/iOS Simulator/unsigned iOS device builds and six runtime executions. The single app and dedicated UI-plus-service variants activated and showed app-owned UI on macOS/iOS Simulator; invalid schema metadata failed boot and kept module UI inactive. Final simulator screenshots were visually reviewed. Canonical policies/templates, the 34-file inventory, portable tools, negative fixtures, and byte-identical repeated packaging were verified.

The actual execution environment was macOS 27.0.1 and iOS 27.0 Simulator on arm64 with Xcode 27.0/Swift 6.4. Signed device installation, physical-device acceptance, and minimum-OS execution were not performed. Read the [qualification results](https://github.com/flynn33/Forsetti-Framework-Mac-iOS/blob/main/docs/sdk/0.2.0-results.md) and [verification report](https://github.com/flynn33/Forsetti-Framework-Mac-iOS/releases/download/v0.2.0/Forsetti-SDK-0.2.0-Verification.json) for the evidence boundaries.

Published ZIP SHA-256:

```text
ba909d98362d3e4c8f7f49aa0b6714f0cfa25e5d5f51447fb3a9088003b5407f
```

Downloaded release assets were byte-compared with their local originals and the downloaded ZIP passed the separate source-provenance verifier.
