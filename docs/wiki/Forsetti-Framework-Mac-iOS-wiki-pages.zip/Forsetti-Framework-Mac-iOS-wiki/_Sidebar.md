# Forsetti Wiki

## Start Here

- [Home](Home)
- [Architecture Overview](Architecture-Overview)
- [Integration Patterns](Integration-Patterns)
- [Xcode Templates](Xcode-Templates)

## Runtime Model

- [Runtime Lifecycle](Runtime-Lifecycle)
- [Module Model and Manifests](Module-Model-and-Manifests)
- [Host UI and Surfaces](Host-UI-and-Surfaces)
- [Entitlements and Capabilities](Entitlements-and-Capabilities)
- [Services, Events, and Diagnostics](Services-Events-and-Diagnostics)

## Delivery

- [Testing and Guardrails](Testing-and-Guardrails)
- [Operational Workflows](Operational-Workflows)
- [Versioning and Releases](Versioning-and-Releases)
- [Security, Privacy, and Reliability](Security-Privacy-and-Reliability)
- [Troubleshooting](Troubleshooting)

## Reference

- [API Reference](API-Reference)
- [Glossary and Checklists](Glossary-and-Checklists)
- [License](License)
